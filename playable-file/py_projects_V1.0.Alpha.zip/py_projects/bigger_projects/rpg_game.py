#-----------------------------------------Created-By-Justin----------------------------------------
#Time-Spent:-07d-15h-28m-47s-----------------------------------------------------------------------
#Progress:-74%-(could-be-less)---------------------------------------------------------------------
#Wait-for-updates-:)-------------------------------------------------------------------------------
 
#-------------------------------------------Update-Log---------------------------------------------
# Making goblin with fighting mechanism                                            -1.0 rework.v1.0
# Making main menu                                                                 -1.0 rework.v1.1
# Making inventory                                                                 -1.0 rework.v1.2
# Making status and skill point                                                    -1.0 rework.v1.3
# Making intro and color                                                           -1.0 rework.v1.4
# Making races                                                                     -1.0 rework.v1.5
# Making races stats and evlution                                                  -1.0 rework.v1.6
# Making defense mechanism works in battle                                         -1.0 rework.v1.7
# Making loot and gold                                                             -1.0 rework.v1.8
# Making equipment and shop                                                        -1.0 rework.v1.9
# Making auto delete logs and typing                                               -1.0 rework.v2.0
# Making potion                                                                    -1.0 rework.v2.1
# Inventory and Shop Update                                                        -1.0 rework.v2.2
# Monster addon                                                                    -1.0 rework.v2.2
# Skill addon                                                                      -1.0 rework.v2.3
# difficulty choice                                                                -1.0 rework.v2.4
#-----------------------------------------Upcoming-Features-----------------------------------------
#1. More Monster
#2. crafting
#4. Third evolution
#6. more potions
#7. perks of each race

#import -------------------------------------------------------------------------------------------import
import random
import os
import sys
import time
WINDOWS=os.name=='nt'
if WINDOWS:
    import msvcrt
else:
    import termios, tty, select

#The Variables--------------------------------------------------------------------------------------variable
skills=[]
potion=5
inventory={'potion':potion}
equipment={}
experience=0
gold=1000
strength_point=0
defense_point=0
current_weapon='nothing'
current_armor='nothing'
game_difficulty=f"nothing"
difficulty_rate=0

#Shop Price------------------------------------------------------------------------------------------price
potion_price=250
dagger_price=1000
sword_price=1700
iron_armor_price=2300
sell_price={"potion_sell":100, "dagger_sell":350, "sword_sell":1000, "stick_sell":50, "torn_cloth_sell":150, "goblin_necklace_sell":500}

#The Colors------------------------------------------------------------------------------------------color
BLACK = "\033[0;30m"
RED = "\033[0;31m"
GREEN = "\033[0;32m"
BROWN = "\033[0;33m"
BLUE = "\033[0;34m"
PURPLE = "\033[0;35m"
CYAN = "\033[0;36m"
LIGHT_YELLOW= "\033[1;93m"
LIGHT_GRAY = "\033[0;37m"
GRAY = "\033[1;30m"
DARK_GRAY = "\033[1;30m"
LIGHT_RED = "\033[1;31m"
LIGHT_GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
LIGHT_BLUE = "\033[1;94m"
LIGHT_PURPLE = "\033[1;35m"
LIGHT_CYAN = "\033[1;36m"
LIGHT_WHITE = "\033[1;37m"
BOLD = "\033[1m"
FAINT = "\033[2m"
ITALIC = "\033[3m"
UNDERLINE = "\033[4m"
BLINK = "\033[5m"
NEGATIVE = "\033[7m"
CROSSED = "\033[9m"
END = "\033[0m"

#History Deletion---------------------------------------------------------------------------------History deletion
def delete():
    os.system('cls' if os.name == 'nt' else 'clear')

def clear_keystrokes():
    if WINDOWS:
        while msvcrt.kbhit():
            msvcrt.getch()
    else:
        while select.select([sys.stdin], [], [], 0)[0]:
            sys.stdin.read(1)

def typing(text, delay=0.05):
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()
    if not WINDOWS:
        old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())

    try:
        for c in text:
            clear_keystrokes()
            sys.stdout.write(c)
            sys.stdout.flush()
            time.sleep(delay)
    finally:
        if not WINDOWS:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()

def typingx(text, delay=0.005):
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()
    print()
    if not WINDOWS:
        old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())

    try:
        for c in text:
            clear_keystrokes()
            sys.stdout.write(c)
            sys.stdout.flush()
            time.sleep(delay)
    finally:
        if not WINDOWS:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()

#Races stats---------------------------------------------------------------------------------------race stat
def elf_stat():
	typingx(f"{LIGHT_RED}hp: 24{END}")
	typingx(f"{LIGHT_YELLOW}strength:  9{END}")
	typingx(f"{LIGHT_BLUE}defense :  3{END}")
	typingx("strong attack but low defense")
def demon_stat():
	typingx(f"{LIGHT_RED}hp: 31{END}")
	typingx(f"{LIGHT_YELLOW}strength:  8{END}")
	typingx(f"{LIGHT_BLUE}defense :  4{END}")
	typingx("strong attack and medium defense")
def orc_stat():
	typingx(f"{LIGHT_RED}hp: 27{END}")
	typingx(f"{LIGHT_YELLOW}strength:  3{END}")
	typingx(f"{LIGHT_BLUE}defense :  7{END}")
	typingx("strong defense but low attack")
def human_stat():
	typingx(f"{LIGHT_RED}hp:29{END}")
	typingx(f"{LIGHT_YELLOW}strength:  5{END}")
	typingx(f"{LIGHT_BLUE}defense :  5{END}")
	typingx("stable strength and defense")

#difficulty----------------------------------------------------------------------------------------difficulty
def Difficulty_Func():
	while True:
		global game_difficulty,difficulty_rate
		typingx(f"Choose which difficulty you want to play? {GRAY}(Currently not working){END}")
		typingx(f"1. {GREEN}Easy{END}")
		typingx(f"2. {YELLOW}Normal{END}")
		typingx(f"3. {LIGHT_RED}Hard{END}")
		try:
			difficulty_choice=int(input("> "))
			if difficulty_choice==1:
				typingx(f"{GREEN}Easy{END}")
				typingx("you will start with double defense and hp")
				print()
				final_desicion=input("are you sure you want to do this difficulty?y/n >")
				if final_desicion=="y":
					game_difficulty=f"{GREEN}Easy{END}"
				else:
					Difficulty_Func()
			if difficulty_choice==2:
				typingx(f"{YELLOW}Normal{END}")
				typingx("The usual stats")
				print()
				final_desicion=input("are you sure you want to do this difficulty?y/n >")
				if final_desicion=="y":
					game_difficulty=f"{YELLOW}Normal{END}"
				else:
					Difficulty_Func()
			if difficulty_choice==3:
				typingx(f"{LIGHT_RED}Hard{END}")
				typingx("you will start with halved hp")
				print()
				final_desicion=input("are you sure you want to do this difficulty?y/n >")
				if final_desicion=="y":
					game_difficulty=f"{LIGHT_RED}Hard{END}"
				else:
					Difficulty_Func()
		except ValueError:
			print("enter a number")
			Difficulty_Func()
		finally:
			break
	if game_difficulty==f"{GREEN}Easy{END}":
		difficulty_rate=1
	if game_difficulty==f"{YELLOW}Normal{END}":
		difficulty_rate= 2
	if game_difficulty==f"{RED}Hard{END}":
		difficulty_rate=3
	intro()
	

#intro---------------------------------------------------------------------------------------------intro
def intro():
	delete()
	input(typing(f"you just got reincarnated in another world. {DARK_GRAY}click enter to continue{BLACK}"))
	input(typing(f"{END}you found yourself awake in the forest, alone.{DARK_GRAY}click enter to continue{BLACK}"))
	races()
		
def races():
	global race
	while True:
		typing(f"{END}you look at your reflection in the water. you are a...")
		print()
		typingx("1. Elf   3. Orc")
		typingx("2. Demon 4. Human")
		print()
		try:
			r=int(input(">"))
		except ValueError:
			print("thats not a valid option")
			delete()
			continue
		if r==1:
			race=f'{LIGHT_GREEN}Elf{END}'
			race_name='an Elf'
			break
		if r==2:
			race=f'{RED}Demon{END}'
			race_name='a Demon'
			break
		if r==3:
			race=f'{GREEN}Orc{END}'
			race_name='an Orc'
			break
		if r==4:
			race=f'{YELLOW}Human{END}'
			race_name='a Human'
			break
	typing(f"you are {race_name}? y/n")
	print()
	if race==f'{LIGHT_GREEN}Elf{END}':
		typingx(f"{LIGHT_GREEN}----------------Elf----------------{END}")
		elf_stat()
	elif race==f'{RED}Demon{END}':
		typingx(f"{RED}---------------Demon---------------{END}")
		demon_stat()
	elif race==f'{GREEN}Orc{END}':
		typingx(f"{GREEN}----------------Orc----------------{END}")
		orc_stat()
	elif race==f'{YELLOW}Human{END}':
		typingx(f"{YELLOW}---------------Human---------------{END}")
		human_stat()
	if race==f'{LIGHT_GREEN}Elf{END}':
		typingx(f"{LIGHT_GREEN}---------------Skill---------------{END}")
		typingx(f"1.{LIGHT_GREEN}Double Arrow{END}")
		typingx(f"2.{LIGHT_GREEN}Sharp Eye{END}")
		typingx(f"{LIGHT_GREEN}-----------------------------------{END}")
		print()
	elif race==f'{RED}Demon{END}':
		typingx(f"{RED}---------------Skill---------------{END}")
		typingx(f"1.{RED}Life Steal{END}")
		typingx(f"2.{LIGHT_RED}Rage{END}")
		typingx(f"{RED}-----------------------------------{END}")
		print()
	elif race==f'{GREEN}Orc{END}':
		typingx(f"{GREEN}---------------Skill---------------{END}")
		typingx(f"1.{YELLOW}Throw{END}")
		typingx(f"2.{GREEN}Heavy Attack{END}")
		typingx(f"{GREEN}-----------------------------------{END}")
		print()
	elif race==f'{YELLOW}Human{END}':
		typingx(f"{YELLOW}---------------Skill---------------{END}")
		typingx(f"1.{BLUE}Triple Slash{END}")
		typingx(f"2.{RED}Rage{END}")
		typingx(f"{YELLOW}-----------------------------------{END}")
		print()
	rchoice=input('>')
	if rchoice=='y':
		name()
	if rchoice=='n':
		delete()
		races()

def name():
	global my_name
	typing("whats your name?")
	my_name=input(">")
	typing(f"does your name is {my_name} correct? y/n")
	print()
	ch=input(">")
	if ch=='y':
		typing(f"welcome, {my_name} to the limitless fantasy.")
		input(f"{DARK_GRAY}click enter to continue{END}")
		strace()
	else:
		delete()
		name()

#The Main Menu-------------------------------------------------------------------------------------main menu
def main_menu():
	while True:
		delete()
		global hp, my_level,totalhp, mp, difficulty_rate
		my_level=my_level_func()
		mp=4-3+my_level*3
		totalhp=hp-3+my_level*3
		if difficulty_rate==1:
			totalhp*=2
		if difficulty_rate==3:
			totalhp/2
		typing("what you gonna do?")
		print()
		print("1. explore            4. Craft")
		print("2. check inventory    5. shop")
		print("3. check status       6.exit")
		try:
			aa=int(input(">"))
			if aa==1:
				print()
				game()
			if aa==2:
				print()
				check_inventory()
			if aa==3:
				print()
				check_status()
			if aa==4:
				print()
				crafting()
			if aa==5:
				print()
				shop()
			if aa==6:
				print()
				exit()
				break
			else:
				continue
		except ValueError:
			continue

#1. Explore---------------------------------------------------------------------------------------1
def game():
	print("Choose where you want to explore:")
	print(f"1.Forest {DARK_GRAY}level 1-10{END}")
	print(f"2.Cave   {DARK_GRAY}level 10-25{END}")
	print(f"3.Dungeon {DARK_GRAY}level 25-50{END}")
	pick=int(input(">"))
	if pick==1:
		typing("You wandering into the forest...")
		input(f"{DARK_GRAY}click enter to continue{END}")
		monster=int(random.randrange(1,5))
		if monster==1:
			goblin()
		if monster==2:
			slime()
		if monster==3:
			bandit()
		if monster==4:
			wolf()
	if pick==2:
		if my_level<10:
			print("your level still lower than 10")
			input(f"{DARK_GRAY}click enter to continue{END}")
		else:
			typing("you exploring through a cave...")
			input(f"{DARK_GRAY}click enter to continue{END}")
			monscave=int(random.randrange(1,5))
			if monscave==1:
				skeleton()
			if monscave==2:
				zombie()
			if monscave==3:
				ghost()
			if monscave==4:
				hogoblin()
	if pick==3:
		if my_level<25:
			print("your level still lower than 10")
			input(f"{DARK_GRAY}click enter to continue{END}")
		else:
			typing("you have dicovered an dungeon...")
			input(f"{DARK_GRAY}click enter to continue{END}")
			typing("you start exploring the dungeon...")
			input(f"{DARK_GRAY}click enter to continue{END}")
			dungeomy_nameon=int(random.randrange(1,5))
			if dungeomy_nameon==1:
				skeleton()
				zombie()
				skeleton_king()
			if dungeomy_nameon==2:
				zombie()
				zombie()
				zombie_king()
			if dungeomy_nameon==3:
				skeleton()
				skeleton()
				skeleton_king()
			if dungeomy_nameon==4:
				zombie()
				skeleton()
				zombie_king()

#2. Check Inventory--------------------------------------------------------------------------------2
def equipmential():
    if not equipment:
        typingx("You don't have any equipment.")
        input(f"{DARK_GRAY}Press Enter to continue{END}")
        main_menu()
    typingx(f"{LIGHT_YELLOW}--------INVENTORY--------{END}")
    for idx, (itm, count) in enumerate(equipment.items(), start=1):
        typingx(f"{idx}. {itm}: {count}")
    typingx(f"{LIGHT_YELLOW}-------------------------{END}")
    print()
    choice = input("Which item do you want to use? > ")
    try:
        choice = int(choice)
        if choice < 1 or choice > len(equipment):
            typingx("Invalid choice.")
            input(f"{DARK_GRAY}Press Enter to continue{END}")
            equipmential()
    except ValueError:
        typingx("Please enter a number.")
        input(f"{DARK_GRAY}Press Enter to continue{END}")
        main_menu()
    itm = list(equipment.keys())[choice - 1]
    global equipment_picked,current_weapon,current_armor
    equipment_picked=itm
    if itm==current_weapon:
    	typingx("you already used the weapon")
    if itm==current_armor:
    	typingx("you already used the armor")
    elif itm == "Sword":
        sword_stats()
        weapon_equipping_func()
        typingx(f"You equipped {itm}")
    elif itm == "Dagger":
        dagger_stats()
        weapon_equipping_func()
        typingx(f"You equipped {itm}")
    elif itm == "Iron Armor":
        iron_armor_stats()
        armor_equipping_func()
        typingx(f"You equipped {itm}")
    else:
        typingx(f"{DARK_GRAY}Nothing special happens.{END}")

    input(f"{DARK_GRAY}Press Enter to continue{END}")


def inventorial():
	if not inventory:
		typingx("you dont have any items")
		input(f"{DARK_GRAY}click enter to continue{END}")
		main_menu()
	typingx(f"{LIGHT_YELLOW}--------INVENTORY--------{END}")
	for idx, itm in enumerate(inventory):
		for itm, count in inventory.items():
			typingx(f"{idx+1}. {itm}: {count}")
			typingx(f"{LIGHT_YELLOW}-------------------------{END}")
			typingx("what would you do?")
			typingx("1.Inspect")
			typingx("2.Use")
			typingx("3.Move")
			typingx("4.Remove")
			typingx("5.Back")
			incc=int(input(">"))
			if incc==1:
				print("which item you want to inspect?")
			if incc==5:
				main_menu()
			else:
				delete()
				inventorial()
			
def add_equipment(equipm):
	if equipm=='nothing':
		print("the monster didnt drop any equipment")
	if equipm in equipment:
		equipment[equipm] +=1
	else:
		equipment[equipm]=1
		
def add_loot(itm):
		if itm=='nothing':
			print("the monster didnt drop anything")
			return
		if itm in inventory:
			inventory[itm] +=1
		else:
			inventory[itm] =1

def rem_loot(istm):
		if istm=='nothing':
			print("the monster didnt drop anything")
			return
		if istm in inventory:
			inventory[istm] -=1
		else:
			print("you didnt have tha item")

def check_inventory():
	print("what type of item do you want to see?")
	print("1. Gold")
	print("2. Inventory")
	print("3. Equipment")
	inc=int(input(">"))
	if inc==1:
		print(f"you currently have {gold} gold")
		input(f"{DARK_GRAY}click enter to continue{END}")
	if inc==2:
		inventorial()
	if inc==3:
		equipmential()
#3. Check Status------------------------------------------------------------------------------------3
def check_status():
	delete()
	global my_level,totalhp, mp, current_weapon, current_armor,game_difficulty
	print(f"difficulty: {game_difficulty}")
	print(f"name: {my_name}")
	print(f"race: {race}")
	print(f'{LIGHT_RED}hp: {totalhp}/{totalhp}{END}')
	print(f'{BLUE}mp: {mp}/{mp}{END}')
	print(f"level: {my_level}")
	print(f"exp  : {experience} / {10+my_level*6}")
	print(f"weapon: {current_weapon}")
	print(f"armor: {current_armor}")
	print()
	print()
	print("what would you like to do?")
	print("1. check stats  3. evolve")
	print("2. check skill    4. exit")
	stt=int(input(">"))
	if stt==1:
		stat()
	if stt==2:
		skill_preview()
	if stt==3:
		evolve()
	if stt==4:
		main_menu()

#4. Crafting----------------------------------------------------------------------------------------4
def crafting():
	delete()
	print("upcoming features")
	input(f"{GRAY} click enter to continue{END}")

#5. Shop--------------------------------------------------------------------------------------------5
def shop():
	global gold,potion
	print("welcome to the shop")
	print("do you interested on buying or selling item?")
	print("1. Buy")
	print("2. Sell")
	i=int(input(">"))
	if i==1:
		print("------------------Buy------------------")
		print(f"1.Potion                   :{LIGHT_YELLOW}{potion_price} gold{END}")
		print(f"2.Dagger                   :{LIGHT_YELLOW}{dagger_price} gold{END}")
		print(f"3.Sword                    :{LIGHT_YELLOW}{sword_price} gold{END}")
		print(f"4.Iron Armor               :{LIGHT_YELLOW}{iron_armor_price} gold{END}")
		print("--------------------------------------")
		print(f"your gold: {LIGHT_YELLOW}{gold}{END}")
		sh=int(input("what would you like to buy? >"))
		if sh==1:
			if gold<potion_price:
				print("you dont have enough gold")
				input(f"{DARK_GRAY}click enter to continue{END}")
				main_menu()
			else:
				print("how much do you want to buy?")
				shh=int(input(">"))
				if gold<potion_price*shh:
					("you dont have enough gold")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
				else:
					potion+=shh
					potion_amount=0
					while potion_amount<shh:
						add_loot('potion')
						potion_amount+=1
						gold-=potion_price
					print(f"you have bought {shh} potion!")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
		if sh==2:
			if gold<dagger_price:
				print("you dont have enough gold")
				input(f"{DARK_GRAY}click enter to continue{END}")
				main_menu()
			else:
				print("how much do you want to buy?")
				shhd=int(input(">"))
				if gold<dagger_price*shhd:
					("you dont have enough gold")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
				else:
					dagger_amount=0
					while dagger_amount<shhd:
						add_equipment('Dagger')
						dagger_amount+=1
						gold-=dagger_price
					print(f"you have bought {shhd} Dagger!")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
		if sh==3:
			if gold<sword_price:
				print("you dont have enough gold")
				input(f"{DARK_GRAY}click enter to continue{END}")
				main_menu()
			else:
				print("how much do you want to buy?")
				shhs=int(input(">"))
				if gold<sword_price*shhs:
					("you dont have enough gold")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
				else:
					sword_amount=0
					while sword_amount<shhs:
						add_equipment('Sword')
						sword_amount+=1
						gold-=sword_price
					print(f"you have bought {shhs} Sword!")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
		if sh==4:
			if gold<iron_armor_price:
				print("you dont have enough gold")
				input(f"{DARK_GRAY}click enter to continue{END}")
				main_menu()
			else:
				print("how much do you want to buy?")
				shhp=int(input(">"))
				if gold<iron_armor_price*shhp:
					("you dont have enough gold")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
				else:
					iron_armor_amount=0
					while iron_armor_amount<shhp:
						add_equipment('Iron Armor')
						iron_armor_amount+=1
						gold-=iron_armor_price
					print(f"you have bought {shhp} Iron Armor!")
					input(f"{DARK_GRAY}click enter to continue{END}")
					main_menu()
		else:
			typingx("that wasnt an option")
			input(f"{DARK_GRAY}click enter to continue{END}")
			shop()
	if i==2:
		if not inventory:
			print("you dont have anything in your inventory.")
			input(f"{gray} click enter to continue.{END}")
		else:
			list_inventory=list(inventory.items())
			print("------------------Sell------------------")
			for index, (item, count) in enumerate(list_inventory, start=1):
				print(f"{index}. {item}: {count}")
			print("----------------------------------------")
			typingx("what item do you want to sell?")
			while True:
				try:
					selling_choice=int(input(">"))
				except ValueError:
					print("that is not a number")
				finally:
					if 1<=selling_choice<=len(list_inventory):
						break
					else:
						print("that isnt a valid option")
			item_name, item_count = list_inventory[selling_choice - 1]
			print(f"You chose to sell: {item_name}")
			input(">")


#6. Exit--------------------------------------------------------------------------------------------6
def exit():
	print("do you want to exit? y/n")
	inputs=input(">")
	if inputs=='y':
		print("See you later")
		start()
	if inputs=='n':
		main_menu()
#Races Stats config---------------------------------------------------------------------------------racec
def strace():
	global hp, strength_point, defense_point, race,skills
	if race==f'{LIGHT_GREEN}Elf{END}':
		skills.append(f"{LIGHT_GREEN}Double Arrow{END}")
		skills.append(f"{LIGHT_GREEN}Sharp Eye{END}")
	elif race==f'{RED}Demon{END}':
		skills.append(f"{RED}Life Steal{END}")
		skills.append(f"{LIGHT_RED}Rage{END}")
	elif race==f'{GREEN}Orc{END}':
		skills.append(f"{YELLOW}Throw{END}")
		skills.append(f"{GREEN}Heavy Attack{END}")
	elif race==f'{YELLOW}Human{END}':
		skills.append(f"{BLUE}Triple Slash{END}")
		skills.append(f"{BRIGHT_RED}Rage{END}")
	if race==f'{LIGHT_GREEN}Elf{END}':
		hp=24
		strength_point=9
		defense_point=3
	elif race==f'{RED}Demon{END}':
		hp=31
		strength_point=8
		defense_point=4
	elif race==f'{GREEN}Orc{END}':
		hp=27
		strength_point=3
		defense_point=7
	elif race==f'{YELLOW}Human{END}':
		hp=29
		strength_point=5
		defense_point=5
	main_menu()

#Stats----------------------------------------------------------------------------------------------stat
def stat():
	global myhp, strength_point, defense_point
	print()
	totalsp=my_level_func()*3
	sp=totalsp
	while True:
		delete()
		print(f"{LIGHT_YELLOW}--------Stat Menu--------{END}")
		print(f"strength : {strength_point}")
		print(f"defense  : {defense_point}")
		print(f"your sp point is {sp}/{totalsp}")
		print(f"{LIGHT_YELLOW}-------------------------{END}")
		print()
		spup=input("what would you like to upgrade?(str, def or done) >")
		if spup=='done':
			break
		if spup not in ['str', 'def']:
			print("it wasnt an option")
			continue
		try:
			amount=int(input(f"how much you want to upgrade {spup}? >"))
		except:
			print("invalid number")
			continue
		if amount>sp:
			print("you dont have that much of sp")
			continue
		if spup=="str":
			strength_point+=amount
		elif spup=="def":
			defense_point+=amount
		sp-=amount
		print(f"congrats! you've upgraded your {spup} by {amount}")
		print()
		print()
		continue

#Skills-------------------------------------------------------------------------------------------------skill
def skill_preview():
	if race==f'{LIGHT_GREEN}Elf{END}':
		typingx(f"{LIGHT_GREEN}------skill------{END}")
		print()
		for index, all_skill in enumerate(skills):
			print(f"{index+1}. {all_skill}")
		print(f"{LIGHT_GREEN}-----------------{END}")
		print()
	elif race==f'{RED}Demon{END}':
		typingx(f"{RED}------skill------{END}")
		print()
		for index, all_skill in enumerate(skills):
			print(f"{index+1}. {all_skill}")
		print(f"{RED}-----------------{END}")
		print()
	elif race==f'{GREEN}Orc{END}':
		typingx(f"{GREEN}------skill------{END}")
		print()
		for index, all_skill in enumerate(skills):
			print(f"{index+1}. {all_skill}")
		print(f"{GREEN}-----------------{END}")
		print()
	elif race==f'{YELLOW}Human{END}':
		typingx(f"1.{YELLOW}------skill------{END}")
		print()
		for index, all_skill in enumerate(skills):
			print(f"{index+1}. {all_skill}")
		print(f"{YELLOW}-----------------{END}")
		print()
	print("1.skill information")
	print("2.exit")
	preview_choice=int(input("what do you want to do? >"))
	if preview_choice==1:
		if race==f'{LIGHT_GREEN}Elf{END}':
			typingx(f"1.{LIGHT_GREEN}Double Arrow{END}")
			typingx(f"{GRAY}  shoot arrow twice")
			typingx(f"  to the enemy. {END}")
			typingx(f"2.{LIGHT_GREEN}Sharp Eye{END}")
			typingx(f"{GRAY}  increase chance to do")
			typingx(f"  critical damage greatly and hit the enemy{END}")
		elif race==f'{RED}Demon{END}':
			typingx(f"1.{RED}Life Steal{END}")
			typingx(f"{GRAY}  20% of the damage dealt")
			typingx(f"  heals your hp{END}")
			typingx(f"2.{LIGHT_RED}Rage{END}")
			typingx(f"{GRAY}  increase your damage by 1.5X")
			typingx(f"  for 1 turn {END}")
		elif race==f'{GREEN}Orc{END}':
			typingx(f"1.{YELLOW}Throw{END}")
			typingx(f"{GRAY}  deals damage without")
			typingx(f"  getting hit for 1 turn{END}")
			typingx(f"2.{GREEN}Heavy Attack{END}")
			typingx(f"{GRAY}  deals 2x damage")
			typingx(f" for 1 turn{END}")
		elif race==f'{YELLOW}Human{END}':
			typingx(f"1.{BLUE}Triple Slash{END}")
			typingx(f"{GRAY}  deals damage 3 times")
			typingx(f"  but all of them halved for 1 turn{END}")
			typingx(f"2.{LIGHT_RED}Rage{END}")
			typingx(f"{GRAY}  deals 2x damage")
			typingx(f"  for 1 turn{END}")
		print()
		input(f"{GRAY}press enter to continue{END}")
		main_menu()
	else:
		main_menu()
	if ValueError:
		main_menu()
			


#Evolution------------------------------------------------------------------------------------------Evolve
def evolve():
	global race, my_level, strength_point, defense_point
	print(f"Your Current Race: {race}")
	print("would you like to evolve to a:")
	if race==f'{LIGHT_GREEN}Elf{END}':
		print(f"1. {LIGHT_GREEN}Druids{END}")
		print(f"2. {LIGHT_GREEN}High Elf{END}")
		evo=int(input(">"))
		if evo==1:
			print(f"do you want to evolve to a {LIGHT_GREEN}Druids{END}? y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {LIGHT_GREEN}Druids{END}? y/n")
					print("strength  +16")
					print("defense   +17")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{LIGHT_GREEN}Druids{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=16
						defense_point +=17
						print()
					else:
						print()
		if evo==2:
			print(f"do you want to evolve to a {LIGHT_GREEN}High Elf{END} y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {LIGHT_GREEN}High Elf{END}? y/n")
					print("strength  +19")
					print("defense   +14")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{LIGHT_GREEN}High Elf{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=19
						defense_point +=14
						print()
					else:
						print()
	elif race == f'{RED}Demon{END}':
		print(f"1. {RED}Greater Demon{END}")
		print(f"2. {RED}Succubus{END}")
		evo=int(input(">"))
		if evo==1:
			print(f"do you want to evolve to a {RED}Greater Demon{END}? y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {RED}Greater Demon{END}? y/n")
					print("strength  +20")
					print("defense   +16")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{RED}Greater Demon{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=20
						defense_point +=16
						print()
					else:
						print()
		if evo==2:
			print(f"do you want to evolve to a {RED}Succubus{END}? y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {RED}Succubus{END}? y/n")
					print("strength  +15")
					print("defense   +14")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{RED}Succubus{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=15
						defense_point +=14
						print()
					else:
						print()
	elif race == f'{GREEN}Orc{END}':
		print(f"1. {GREEN}Orc Brute{END}")
		print(f"2. {GREEN}Cyclop{END}")
		evo=int(input(">"))
		if evo==1:
			print(f"do you want to evolve to an {GREEN}Orc Brute{END}? y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {GREEN}Orc Brute{END}? y/n")
					print("strength  +17")
					print("defense   +17")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{GREEN}Orc Brute{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=17
						defense_point +=17
						print()
					else:
						print()
		if evo==2:
			print(f"do you want to evolve to a {GREEN}Cyclop{END}? y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {GREEN}Cyclop{END}? y/n")
					print("strength  +28")
					print("defense   +7")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{GREEN}Cyclop{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=28
						defense_point +=7
						print()
					else:
						print()
	elif race==f'{YELLOW}Human{END}':
		print(f"1. {YELLOW}Knight{END}")
		print(f"2. {YELLOW}Guard{END}")
		evo=int(input(">"))
		if evo==1:
			print(f"do you want to evolve to a {YELLOW}Knight{END}? y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {YELLOW}Knight{END}? y/n")
					print("strength  +25")
					print("defense   +7")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{YELLOW}Knight{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=25
						defense_point +=7
						print()
					else:
						print()
		if evo==2:
			print(f"do you want to evolve to a {YELLOW}Guard{END}? y/n (level requirement:25)")
			choice=input(">")
			if choice=='y':
				if my_level<25:
					print("you didnt meet the requirement")
					print()
				if my_level>=25:
					print(f"are you sure you want to evolve to a {YELLOW}Guard{END}? y/n")
					print("strength  +7")
					print("defense   +25")
					evo_choice=input(">")
					if evo_choice=='y':
						race=f'{YELLOW}Guard{END}'
						print(f"congrats! you've evolve to a {race}")
						strength_point +=7
						defense_point +=25
						print()
					else:
						print()
	main_menu()

#Equipments-----------------------------------------------------------------------------------------equipments
def weapon_equipping_func():
	global equipment_picked,strength_point,current_weapon
	if current_weapon != 'nothing':
		if current_weapon == 'Dagger':
			if equipment_picked=='Sword':
				current_weapon=itmpck
				strength_point+=sword_stats()-dagger_stats()
			if equipment_picked=='Goblin bat':
				current_weapon=itmpck
				strength_point+=goblin_bat_stats()-dagger_stats()
		if current_weapon == 'Sword':
			if equipment_picked=='Dagger':
				current_weapon=itmpck
				strength_point+=dagger_stats()-sword_stats()
			if equipment_picked=='Goblin bat':
				current_weapon=itmpck
				strength_point+=goblin_bat_stats()-sword_stats()
		if current_weapon == 'Goblin bat':
			if equipment_picked=='Dagger':
				current_weapon=itmpck
				strength_point+=dagger_stats()-goblin_bat_stats()
			if equipment_picked=='Sword':
				current_weapon=itmpck
				strength_point+=sword_stats()-goblin_bat_stats()
	else:
		if equipment_picked=='Sword':
			current_weapon=equipment_picked
			strength_point+=sword_stats()
		if equipment_picked=='Dagger':
			current_weapon=equipment_picked
			strength_point+=dagger_stats()
		if equipment_picked=='Goblin bat':
			current_weapon=equipment_picked
			strength_point+=goblin_bat_stats()

def armor_equipping_func():
	global equipment_picked, defense_point,current_armor
	if current_armor!='nothing':
		if equipment_picked == 'Iron Armor':
			defense_point+=iron_armor_stats()-leather_armor_stats()
		if equipment_picked == 'leather armor':
			defense_point+=leather_armor_stats()-iron_armor_stats()
	if current_armor=='nothing':
		if equipment_picked == 'Iron Armor':
			defense_point+=iron_armor_stats()
		if equipment_picked == 'leather armor':
			defense_point+=leather_armor_stats()
def sword_stats():
	return 5
def dagger_stats():
	return 3
def goblin_bat_stats():
	return 2
def leather_armor_stats():
	return 5
def iron_armor_stats():
	return 10

#Enemies----------------------------------------------------------------------------------------------Enemies
def get_potion():
	pots=int(random.randrange(1,4))
	if pots==3:
		return 'potion'
	else:
		return 'nothing'
def get_exp():
	expc=int(random.randrange(1,10))
	return expc
def get_gold():
	gold=int(random.randrange(100,1000))
	return gold
#Enemy 1: Goblin--------------------------------------------------------------------------------------enemy1
def goblin():
	def goblin_equipments():
		eqp=int(random.randrange(0,7))
		if  eqp<4:
			return 'nothing'
		if eqp>=4:
			return 'Goblin bat'
		if eqp>=5:
			return 'leather armor'
		if eqp==6:
			return "goblin necklace"
	def goblin_items():
		it=int(random.randrange(0,3))
		if it==0:
			return 'nothing'
			del items[0]
		if it>=1:
			return "torn cloth"
		if it>=2:
			return "stick"
	global totalhp,currenthp,potion
	goblin_level=enemy_level_func()
	typingx(f"youve encountered a level {goblin_level} goblin")
	goblin_defense=goblin_level+3
	goblin_hp=17+goblin_level*9
	currenthp=totalhp
	while goblin_hp>0 and currenthp>0:
		typingx(f"goblin lv.{goblin_level}                         {my_name} lv.{my_level}")
		typingx(f"enemy hp:{LIGHT_RED}{goblin_hp}/{17+goblin_level*9}{END}                      your hp:{LIGHT_RED}{currenthp}/{totalhp}{END}")
		typingx(f"enemy def:{LIGHT_BLUE}{goblin_defense}{END}                        your def:{LIGHT_BLUE}{defense_point}{END}")
		typingx("------------------------------------------------------------")
		typingx("1. attack")
		typingx("2. skill")
		typingx(f"3. use potion: {potion}")
		typingx("4. flee")
		print()
		try:
			typingx("what would you do? ")
			choice=int(input(">"))
			print()
		except ValueError:
			typingx("thats not an option")
			delete()
			continue
		delete()
		if choice==1:
			attack=int(random.randrange(0,6))
			my_attack=attack*strength_point-goblin_defense
			if my_attack<=0:
				my_attack= 0
			if attack>0 and attack<6:
				typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
				goblin_hp-=my_attack
			elif attack==0:
				typingx("you missed!")
			elif attack==6:
				typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
				goblin_hp-=my_attack*2
			global enemy_attack
			enemy_attack=int(random.randrange(0,6))
			if enemy_attack>defense_point/2 and enemy_attack<6:
				typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
			elif enemy_attack>0 and enemy_attack<=defense_point/2:
				typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
			elif enemy_attack==0:
				typingx("The Goblin missed!")
			elif enemy_attack==6:
				typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
			if enemy_attack<=defense_point/2:
				currenthp-=0
			else:
				currenthp=currenthp+defense_point-enemy_attack*2
		elif choice==2:
			if race==f'{LIGHT_GREEN}Elf{END}':
				typingx(f"1.{LIGHT_GREEN}Double Arrow{END}")
				typingx(f"2.{LIGHT_GREEN}Sharp Eye{END}")
				print()
			elif race==f'{RED}Demon{END}':
				typingx(f"1.{RED}Life Steal{END}")
				typingx(f"2.{LIGHT_RED}Rage{END}")
				print()
			elif race==f'{GREEN}Orc{END}':
				typingx(f"1.{YELLOW}Throw{END}")
				typingx(f"2.{GREEN}Heavy Attack{END}")
				print()
			elif race==f'{YELLOW}Human{END}':
				typingx(f"1.{BLUE}Triple Slash{END}")
				typingx(f"2.{RED}Rage{END}")
				print()
			using_choice=int(input("which skill you want to use? >"))
			if using_choice==1 and race==f'{LIGHT_GREEN}Elf{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				my_1st_attack=attack1*strength_point-goblin_defense
				my_2nd_attack=attack2*strength_point-goblin_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					goblin_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					goblin_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage")
					goblin_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage!")
					goblin_hp-=my_2nd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The Goblin missed!")
				elif enemy_attack==6:
					typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{LIGHT_GREEN}Elf{END}':
				attack=int(random.randrange(4,10))
				my_attack=attack*strength_point-goblin_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					goblin_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					goblin_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The Goblin missed!")
				elif enemy_attack==6:
					typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-goblin_defense
				healing=my_attack*0.2
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage and heals {healing} hp")
					goblin_hp-=my_attack
					currenthp+=healing
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage! and heals {healing*2} hp")
					goblin_hp-=my_attack*2
					currenthp+=healing*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The Goblin missed!")
				elif enemy_attack==6:
					typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*1.5-goblin_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					goblin_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					goblin_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The Goblin missed!")
				elif enemy_attack==6:
					typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-goblin_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					goblin_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					goblin_hp-=my_attack*2
			if using_choice==2 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*2-goblin_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					goblin_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					goblin_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The Goblin missed!")
				elif enemy_attack==6:
					typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{YELLOW}Human{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				attack3=int(random.randrange(0,6))
				my_1st_attack=attack1*0.5*strength_point-goblin_defense
				my_2nd_attack=attack2*0.5*strength_point-goblin_defense
				my_3rd_attack=attack3*0.5*strength_point-goblin_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if my_3rd_attack<=0:
					my_3rd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					goblin_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					goblin_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage and ")
					goblin_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage! and ")
					goblin_hp-=my_2nd_attack*2
				if attack3>0 and attack3<6:
					typingx(f"you've dealt {LIGHT_RED}{my_3rd_attack} {END}damage and ")
					goblin_hp-=my_3rd_attack
				elif attack3==0:
					typingx("you missed!")
				elif attack3==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_3rd_attack*2}{END} critical damage! and ")
					goblin_hp-=my_3rd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The Goblin missed!")
				elif enemy_attack==6:
					typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{YELLOW}Human{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*2*strength_point-goblin_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					goblin_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					goblin_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The Goblin dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The Goblin missed!")
				elif enemy_attack==6:
					typingx(f"The goblin dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
		elif choice==3:
			potion-=1
			rem_loot('potion')
			if currenthp+20>totalhp:
				currenthp=totalhp
			else:
				currenthp+=20
			typing("you used a potion")
			print()
			typing(input(f"hp {RED}+20{END}. {DARK_GRAY}click enter to continue{END}"))
		elif choice==4:
			chance=int(random.randrange(1,3))
			if chance==1:
				input(f"you fleed. {DARK_GRAY}click enter to continue{END}")
				print()
				main_menu()
				break
			if chance==2:
				input(f"you failed to flee. {DARK_GRAY}click enter to continue{END}")
				print()
			else:
				continue
	if currenthp<=0:
		print("you lost!")
		print()
		main_menu()
	if goblin_hp<=0:
		goblin_gold=get_gold()
		goblin_exp=get_exp()+goblin_level*2
		print("congrats, you beat the goblin!")
		print(f"youve earned {goblin_exp} exp and {goblin_gold} gold!")
		loot=goblin_items()
		if loot!='nothing':
			add_loot(loot)
			print(f"you've earned {loot}")
		goblin_potion=get_potion()
		if goblin_potion!='nothing':
			add_loot(goblin_potion)
			print(f"you've earned a potion!")
		equipment_loot_from_enemy=goblin_equipments()
		if equipment_loot_from_enemy!='nothing':
			add_equipment(equipment_loot_from_enemy)
			print(f"you also earned {equipment_loot_from_enemy}")
		global experience, gold
		experience+=goblin_exp
		gold+=goblin_gold
		input("press enter to continue")
		main_menu()

#Enemy 2: Slime--------------------------------------------------------------------------------------enemy2
def slime():
	def Slime_items():
		it=int(random.randrange(0,2))
		if it==0:
			return 'nothing'
			del items[0]
		if it>=1:
			return "gel"
	global totalhp,currenthp,potion
	Slime_Level=enemy_level_func()
	typingx(f"youve encountered a level {Slime_Level} slime")
	slime_defense=Slime_Level
	slime_hp=17+Slime_Level*4
	currenthp=totalhp
	while slime_hp>0 and currenthp>0:
		typingx(f"Slime lv.{Slime_Level}                         {my_name} lv.{my_level}")
		typingx(f"enemy hp:{LIGHT_RED}{slime_hp}/{17+Slime_Level*4}{END}                      your hp:{LIGHT_RED}{currenthp}/{totalhp}{END}")
		typingx(f"enemy def:{LIGHT_BLUE}{slime_defense}{END}                        your def:{LIGHT_BLUE}{defense_point}{END}")
		typingx("------------------------------------------------------------")
		typingx("1. attack")
		typingx("2. skill")
		typingx(f"3. use potion: {potion}")
		typingx("4. flee")
		print()
		try:
			typingx("what would you do? ")
			choice=int(input(">"))
			print()
		except ValueError:
			typingx("thats not an option")
			delete()
			continue
		delete()
		if choice==1:
			attack=int(random.randrange(0,6))
			my_attack=attack*strength_point-slime_defense
			if attack>0 and attack<6:
				if my_attack<=0:
					my_attack= 0
				typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
				slime_hp-=my_attack
			elif attack==0:
				typingx("you missed!")
			elif attack==6:
				typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
				slime_hp-=my_attack*2
			global enemy_attack
			enemy_attack=int(random.randrange(0,6))
			if enemy_attack>defense_point/2 and enemy_attack<6:
				typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
			elif enemy_attack>0 and enemy_attack<=defense_point/2:
				typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
			elif enemy_attack==0:
				typingx("The slime missed!")
			elif enemy_attack==6:
				typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
			if enemy_attack<=defense_point/2:
				currenthp-=0
			else:
				currenthp=currenthp+defense_point-enemy_attack*2
		elif choice==2:
			if race==f'{LIGHT_GREEN}Elf{END}':
				typingx(f"1.{LIGHT_GREEN}Double Arrow{END}")
				typingx(f"2.{LIGHT_GREEN}Sharp Eye{END}")
				print()
			elif race==f'{RED}Demon{END}':
				typingx(f"1.{RED}Life Steal{END}")
				typingx(f"2.{LIGHT_RED}Rage{END}")
				print()
			elif race==f'{GREEN}Orc{END}':
				typingx(f"1.{YELLOW}Throw{END}")
				typingx(f"2.{GREEN}Heavy Attack{END}")
				print()
			elif race==f'{YELLOW}Human{END}':
				typingx(f"1.{BLUE}Triple Slash{END}")
				typingx(f"2.{RED}Rage{END}")
				print()
			using_choice=int(input("which skill you want to use? >"))
			if using_choice==1 and race==f'{LIGHT_GREEN}Elf{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				my_1st_attack=attack1*strength_point-slime_defense
				my_2nd_attack=attack2*strength_point-slime_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					slime_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					slime_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage")
					slime_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage!")
					slime_hp-=my_2nd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The slime missed!")
				elif enemy_attack==6:
					typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{LIGHT_GREEN}Elf{END}':
				attack=int(random.randrange(4,10))
				my_attack=attack*strength_point-slime_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					slime_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					slime_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The slime missed!")
				elif enemy_attack==6:
					typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-slime_defense
				healing=my_attack*0.2
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage and heals {healing} hp")
					slime_hp-=my_attack
					currenthp+=healing
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage! and heals {healing*2} hp")
					slime_hp-=my_attack*2
					currenthp+=healing*2
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The slime missed!")
				elif enemy_attack==6:
					typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*1.5-slime_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					slime_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					slime_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The slime missed!")
				elif enemy_attack==6:
					typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-slime_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					slime_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					slime_hp-=my_attack*2
			if using_choice==2 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*2-slime_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					slime_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					slime_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The slime missed!")
				elif enemy_attack==6:
					typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{YELLOW}Human{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				attack3=int(random.randrange(0,6))
				my_1st_attack=attack1*0.5*strength_point-slime_defense
				my_2nd_attack=attack2*0.5*strength_point-slime_defense
				my_3rd_attack=attack3*0.5*strength_point-slime_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if my_3rd_attack<=0:
					my_3rd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					slime_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					slime_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage and ")
					slime_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage! and ")
					slime_hp-=my_2nd_attack*2
				if attack3>0 and attack3<6:
					typingx(f"you've dealt {LIGHT_RED}{my_3rd_attack} {END}damage and ")
					slime_hp-=my_3rd_attack
				elif attack3==0:
					typingx("you missed!")
				elif attack3==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_3rd_attack*2}{END} critical damage! and ")
					slime_hp-=my_3rd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The slime missed!")
				elif enemy_attack==6:
					typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{YELLOW}Human{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*2*strength_point-slime_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					slime_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					slime_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The slime dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The slime missed!")
				elif enemy_attack==6:
					typingx(f"The slime dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
		elif choice==3:
			potion-=1
			rem_loot('potion')
			if currenthp+20>totalhp:
				currenthp=totalhp
			else:
				currenthp+=20
			typing("you used a potion")
			print()
			typing(input(f"hp {RED}+20{END}. {DARK_GRAY}click enter to continue{END}"))
		elif choice==4:
			chance=int(random.randrange(1,3))
			if chance==1:
				input(f"you fleed. {DARK_GRAY}click enter to continue{END}")
				print()
				main_menu()
				break
			if chance==2:
				input(f"you failed to flee. {DARK_GRAY}click enter to continue{END}")
				print()
			else:
				continue
	if currenthp<=0:
		print("you lost!")
		print()
		main_menu()
	if slime_hp<=0:
		Slime_gold=get_gold()
		Slime_exp=get_exp()+Slime_Level*2
		print("congrats, you beat the slime!")
		print(f"youve earned {Slime_exp} exp and {Slime_gold} gold!")
		loot=Slime_items()
		if loot!='nothing':
			add_loot(loot)
			print(f"you've earned {loot}")
		Slime_potion=get_potion()
		if Slime_potion!='nothing':
			add_loot(Slime_potion)
			print(f"you've earned a potion!")
		global experience, gold
		experience+=Slime_exp
		gold+=Slime_gold
		input("press enter to continue")
		main_menu()

#Enemy 3: Bandit--------------------------------------------------------------------------------------enemy3
def bandit():
	def bandit_equipments():
		eqp=int(random.randrange(0,7))
		if  eqp<5:
			return 'nothing'
		if eqp>=5:
			return 'dagger'
	def bandit_items():
		it=int(random.randrange(0,3))
		if it==0:
			return 'nothing'
			del items[0]
		if it>=1:
			return "torn cloth"
	global totalhp,currenthp,potion
	bandit_level=enemy_level_func()
	typingx(f"youve encountered a level {bandit_level} bandit")
	bandit_defense=bandit_level+6
	bandit_hp=17+bandit_level*15
	currenthp=totalhp
	while bandit_hp>0 and currenthp>0:
		typingx(f"bandit lv.{bandit_level}                         {my_name} lv.{my_level}")
		typingx(f"enemy hp:{LIGHT_RED}{bandit_hp}/{17+bandit_level*15}{END}                      your hp:{LIGHT_RED}{currenthp}/{totalhp}{END}")
		typingx(f"enemy def:{LIGHT_BLUE}{bandit_defense}{END}                        your def:{LIGHT_BLUE}{defense_point}{END}")
		typingx("------------------------------------------------------------")
		typingx("1. attack")
		typingx("2. skill")
		typingx(f"3. use potion: {potion}")
		typingx("4. flee")
		print()
		try:
			typingx("what would you do? ")
			choice=int(input(">"))
			print()
		except ValueError:
			typingx("thats not an option")
			delete()
			continue
		delete()
		if choice==1:
			attack=int(random.randrange(0,6))
			my_attack=attack*strength_point-bandit_defense
			if my_attack<=0:
				my_attack= 0
			if attack>0 and attack<6:
				typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
				bandit_hp-=my_attack*2
			elif attack==0:
				typingx("you missed!")
			elif attack==6:
				typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
				bandit_hp-=my_attack*2
			global enemy_attack
			enemy_attack=int(random.randrange(0,6))
			if enemy_attack>defense_point/2 and enemy_attack<6:
				typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
			elif enemy_attack>0 and enemy_attack<=defense_point/2:
				typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
			elif enemy_attack==0:
				typingx("The bandit missed!")
			elif enemy_attack==6:
				typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
			if enemy_attack<=defense_point/2:
				currenthp-=0
			else:
				currenthp=currenthp+defense_point-enemy_attack*2
		elif choice==2:
			if race==f'{LIGHT_GREEN}Elf{END}':
				typingx(f"1.{LIGHT_GREEN}Double Arrow{END}")
				typingx(f"2.{LIGHT_GREEN}Sharp Eye{END}")
				print()
			elif race==f'{RED}Demon{END}':
				typingx(f"1.{RED}Life Steal{END}")
				typingx(f"2.{LIGHT_RED}Rage{END}")
				print()
			elif race==f'{GREEN}Orc{END}':
				typingx(f"1.{YELLOW}Throw{END}")
				typingx(f"2.{GREEN}Heavy Attack{END}")
				print()
			elif race==f'{YELLOW}Human{END}':
				typingx(f"1.{BLUE}Triple Slash{END}")
				typingx(f"2.{RED}Rage{END}")
				print()
			using_choice=int(input("which skill you want to use? >"))
			if using_choice==1 and race==f'{LIGHT_GREEN}Elf{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				my_1st_attack=attack1*strength_point-bandit_defense
				my_2nd_attack=attack2*strength_point-bandit_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					bandit_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					bandit_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage")
					bandit_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage!")
					bandit_hp-=my_2nd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The bandit missed!")
				elif enemy_attack==6:
					typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{LIGHT_GREEN}Elf{END}':
				attack=int(random.randrange(4,10))
				my_attack=attack*strength_point-bandit_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					bandit_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					bandit_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The bandit missed!")
				elif enemy_attack==6:
					typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-bandit_defense
				healing=my_attack*0.2
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage and heals {healing} hp")
					bandit_hp-=my_attack
					currenthp+=healing
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage! and heals {healing*2} hp")
					bandit_hp-=my_attack*2
					currenthp+=healing*2
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The bandit missed!")
				elif enemy_attack==6:
					typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*1.5-bandit_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					bandit_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					bandit_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The bandit missed!")
				elif enemy_attack==6:
					typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-bandit_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					bandit_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					bandit_hp-=my_attack*2
			if using_choice==2 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*2-bandit_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					bandit_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					bandit_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The bandit missed!")
				elif enemy_attack==6:
					typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{YELLOW}Human{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				attack3=int(random.randrange(0,6))
				my_1st_attack=attack1*0.5*strength_point-bandit_defense
				my_2nd_attack=attack2*0.5*strength_point-bandit_defense
				my_3rd_attack=attack3*0.5*strength_point-bandit_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if my_3rd_attack<=0:
					my_3rd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					bandit_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					bandit_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage and ")
					bandit_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage! and ")
					bandit_hp-=my_2nd_attack*2
				if attack3>0 and attack3<6:
					typingx(f"you've dealt {LIGHT_RED}{my_3rd_attack} {END}damage and ")
					bandit_hp-=my_3rd_attack
				elif attack3==0:
					typingx("you missed!")
				elif attack3==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_3rd_attack*2}{END} critical damage! and ")
					bandit_hp-=my_3rd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The bandit missed!")
				elif enemy_attack==6:
					typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{YELLOW}Human{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*2*strength_point-bandit_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					bandit_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					bandit_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The bandit dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The bandit missed!")
				elif enemy_attack==6:
					typingx(f"The bandit dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
		elif choice==3:
			potion-=1
			rem_loot('potion')
			if currenthp+20>totalhp:
				currenthp=totalhp
			else:
				currenthp+=20
			typing("you used a potion")
			print()
			typing(input(f"hp {RED}+20{END}. {DARK_GRAY}click enter to continue{END}"))
		elif choice==4:
			chance=int(random.randrange(1,3))
			if chance==1:
				input(f"you fleed. {DARK_GRAY}click enter to continue{END}")
				print()
				main_menu()
				break
			if chance==2:
				input(f"you failed to flee. {DARK_GRAY}click enter to continue{END}")
				print()
			else:
				continue
	if currenthp<=0:
		print("you lost!")
		print()
		main_menu()
	if bandit_hp<=0:
		bandit_gold=get_gold()
		bandit_exp=get_exp()+bandit_level*2
		print("congrats, you beat the bandit!")
		print(f"youve earned {bandit_exp} exp and {bandit_gold} gold!")
		loot=bandit_items()
		if loot!='nothing':
			add_loot(loot)
			print(f"you've earned {loot}")
		bandit_potion=get_potion()
		if bandit_potion!='nothing':
			add_loot(bandit_potion)
			print(f"you've earned a potion!")
		equipment_loot_from_enemy=bandit_equipments()
		if equipment_loot_from_enemy!='nothing':
			add_equipment(equipment_loot_from_enemy)
			print(f"you also earned {equipment_loot_from_enemy}")
		global experience, gold
		experience+=bandit_exp
		gold+=bandit_gold
		input("press enter to continue")
		main_menu()

#Enemy 4: Wolf--------------------------------------------------------------------------------------enemy4
def wolf():
	def wolf_items():
		it=int(random.randrange(0,3))
		if it==0:
			return 'nothing'
			del items[0]
		if it>=1:
			return "wolf fang"
		if it>=2:
			return "wolf claw"
	global totalhp,currenthp,potion
	wolf_level=enemy_level_func()
	typingx(f"youve encountered a level {wolf_level} wolf")
	wolf_defense=wolf_level+6
	wolf_hp=30+wolf_level*9
	currenthp=totalhp
	while wolf_hp>0 and currenthp>0:
		typingx(f"wolf lv.{wolf_level}                         {my_name} lv.{my_level}")
		typingx(f"enemy hp:{LIGHT_RED}{wolf_hp}/{30+wolf_level*9}{END}                      your hp:{LIGHT_RED}{currenthp}/{totalhp}{END}")
		typingx(f"enemy def:{LIGHT_BLUE}{wolf_defense}{END}                        your def:{LIGHT_BLUE}{defense_point}{END}")
		typingx("------------------------------------------------------------")
		typingx("1. attack")
		typingx("2. skill")
		typingx(f"3. use potion: {potion}")
		typingx("4. flee")
		print()
		try:
			typingx("what would you do? ")
			choice=int(input(">"))
			print()
		except ValueError:
			typingx("thats not an option")
			delete()
			continue
		delete()
		if choice==1:
			attack=int(random.randrange(0,6))
			my_attack=attack*strength_point-wolf_defense
			if my_attack<=0:
				my_attack= 0
			if attack>0 and attack<6:
				typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
				wolf_hp-=my_attack
			elif attack==0:
				typingx("you missed!")
			elif attack==6:
				typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
				wolf_hp-=my_attack*2
			global enemy_attack
			enemy_attack=int(random.randrange(0,6))
			if enemy_attack>defense_point/2 and enemy_attack<6:
				typingx(f"The the wolf dealt {LIGHT_RED}{enemy_attack*4-defense_point} {END}damage")
			elif enemy_attack>0 and enemy_attack<=defense_point/2:
				typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
			elif enemy_attack==0:
				typingx("The wolf missed!")
			elif enemy_attack==6:
				typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*6-defense_point}{END} damage!")
			if enemy_attack<=defense_point/2:
				currenthp-=0
			else:
				currenthp=currenthp+defense_point-enemy_attack*4
		elif choice==2:
			if race==f'{LIGHT_GREEN}Elf{END}':
				typingx(f"1.{LIGHT_GREEN}Double Arrow{END}")
				typingx(f"2.{LIGHT_GREEN}Sharp Eye{END}")
				print()
			elif race==f'{RED}Demon{END}':
				typingx(f"1.{RED}Life Steal{END}")
				typingx(f"2.{LIGHT_RED}Rage{END}")
				print()
			elif race==f'{GREEN}Orc{END}':
				typingx(f"1.{YELLOW}Throw{END}")
				typingx(f"2.{GREEN}Heavy Attack{END}")
				print()
			elif race==f'{YELLOW}Human{END}':
				typingx(f"1.{BLUE}Triple Slash{END}")
				typingx(f"2.{RED}Rage{END}")
				print()
			using_choice=int(input("which skill you want to use? >"))
			if using_choice==1 and race==f'{LIGHT_GREEN}Elf{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				my_1st_attack=attack1*strength_point-wolf_defense
				my_2nd_attack=attack2*strength_point-wolf_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					wolf_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					wolf_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage")
					wolf_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage!")
					wolf_hp-=my_2nd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The wolf dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The wolf missed!")
				elif enemy_attack==6:
					typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{LIGHT_GREEN}Elf{END}':
				attack=int(random.randrange(4,10))
				my_attack=attack*strength_point-wolf_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					wolf_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					wolf_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The wolf dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The wolf missed!")
				elif enemy_attack==6:
					typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-wolf_defense
				healing=my_attack*0.2
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage and heals {healing} hp")
					wolf_hp-=my_attack
					currenthp+=healing
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage! and heals {healing*2} hp")
					wolf_hp-=my_attack*2
					currenthp+=healing*2
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The wolf dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The wolf missed!")
				elif enemy_attack==6:
					typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{RED}Demon{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*1.5-wolf_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					wolf_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					wolf_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The wolf dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The wolf missed!")
				elif enemy_attack==6:
					typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point-wolf_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					wolf_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					wolf_hp-=my_attack*2
			if using_choice==2 and race==f'{GREEN}Orc{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*strength_point*2-wolf_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					wolf_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					wolf_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The wolf dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The wolf missed!")
				elif enemy_attack==6:
					typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==1 and race==f'{YELLOW}Human{END}':
				attack1=int(random.randrange(0,6))
				attack2=int(random.randrange(0,6))
				attack3=int(random.randrange(0,6))
				my_1st_attack=attack1*0.5*strength_point-wolf_defense
				my_2nd_attack=attack2*0.5*strength_point-wolf_defense
				my_3rd_attack=attack3*0.5*strength_point-wolf_defense
				if my_1st_attack<=0:
					my_1st_attack= 0
				if my_2nd_attack<=0:
					my_2nd_attack=0
				if my_3rd_attack<=0:
					my_3rd_attack=0
				if attack1>0 and attack1<6:
					typingx(f"you've dealt {LIGHT_RED}{my_1st_attack} {END}damage and ")
					wolf_hp-=my_1st_attack
				elif attack1==0:
					typingx("you missed! and ")
				elif attack1==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_1st_attack*2}{END} critical damage! and ")
					wolf_hp-=my_1st_attack*2
				if attack2>0 and attack2<6:
					typingx(f"you've dealt {LIGHT_RED}{my_2nd_attack} {END}damage and ")
					wolf_hp-=my_2nd_attack
				elif attack2==0:
					typingx("you missed!")
				elif attack2==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_2nd_attack*2}{END} critical damage! and ")
					wolf_hp-=my_2nd_attack*2
				if attack3>0 and attack3<6:
					typingx(f"you've dealt {LIGHT_RED}{my_3rd_attack} {END}damage and ")
					wolf_hp-=my_3rd_attack
				elif attack3==0:
					typingx("you missed!")
				elif attack3==6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_3rd_attack*2}{END} critical damage! and ")
					wolf_hp-=my_3rd_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The wolf dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The wolf missed!")
				elif enemy_attack==6:
					typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
			if using_choice==2 and race==f'{YELLOW}Human{END}':
				attack=int(random.randrange(0,6))
				my_attack=attack*2*strength_point-wolf_defense
				if my_attack<=0:
					my_attack= 0
				if attack>0 and attack<6:
					typingx(f"you've dealt {LIGHT_RED}{my_attack} {END}damage")
					wolf_hp-=my_attack
				elif attack==0:
					typingx("you missed!")
				elif attack>=6:
					typingx(f"wow! you dealt {LIGHT_YELLOW}{my_attack*2}{END} critical damage!")
					wolf_hp-=my_attack*2
				
				enemy_attack=int(random.randrange(0,6))
				if enemy_attack>defense_point/2 and enemy_attack<6:
					typingx(f"The wolf dealt {LIGHT_RED}{enemy_attack*2-defense_point} {END}damage")
				elif enemy_attack>0 and enemy_attack<=defense_point/2:
					typingx(f"youve {LIGHT_BLUE}blocked{END} the attack!")
				elif enemy_attack==0:
					typingx("The wolf missed!")
				elif enemy_attack==6:
					typingx(f"The wolf dealt a critical {LIGHT_YELLOW}{enemy_attack*2-defense_point}{END} damage!")
				if enemy_attack<=defense_point/2:
					currenthp-=0
				else:
					currenthp=currenthp+defense_point-enemy_attack*2
		elif choice==3:
			potion-=1
			rem_loot('potion')
			if currenthp+20>totalhp:
				currenthp=totalhp
			else:
				currenthp+=20
			typing("you used a potion")
			print()
			typing(input(f"hp {RED}+20{END}. {DARK_GRAY}click enter to continue{END}"))
		elif choice==4:
			chance=int(random.randrange(1,3))
			if chance==1:
				input(f"you fleed. {DARK_GRAY}click enter to continue{END}")
				print()
				main_menu()
				break
			if chance==2:
				input(f"you failed to flee. {DARK_GRAY}click enter to continue{END}")
				print()
			else:
				continue
	if currenthp<=0:
		print("you lost!")
		print()
		main_menu()
	if wolf_hp<=0:
		wolf_gold=get_gold()
		wolf_exp=get_exp()+wolf_level*2
		print("congrats, you beat the wolf!")
		print(f"youve earned {wolf_exp} exp and {wolf_gold} gold!")
		loot=wolf_items()
		if loot!='nothing':
			add_loot(loot)
			print(f"you've earned {loot}")
		wolf_potion=get_potion()
		if wolf_potion!='nothing':
			add_loot(wolf_potion)
			print(f"you've earned a potion!")
		global experience, gold
		experience+=wolf_exp
		gold+=wolf_gold
		input("press enter to continue")
		main_menu()

#Leveling system------------------------------------------------------------------------------Level
def enemy_level_func():
	enemy_lvl=int(random.randrange(1,11))
	return enemy_lvl

def my_level_func():
	my_level=1
	ollevel=my_level
	needed=10+my_level*6
	global experience
	while experience>= needed:
		my_level+=1
		experience-=needed
	return my_level


#starting up----------------------------------------------------------------------------------Boot-up
def start():
	while True:
		print(f"{LIGHT_RED}do you want to play? y/n{END} ")
		imputs=input(">")
		if imputs=='y':
			Difficulty_Func()
		if imputs=='n':
			print("goodbye")
		else:
			delete()
start()
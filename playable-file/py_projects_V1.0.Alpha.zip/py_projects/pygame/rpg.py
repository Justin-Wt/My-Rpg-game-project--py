import pygame,pgzrun,random

WIDTH = 1200
HEIGHT = 600
fullscreen = True
txt=False
current_message=""

alien=Actor("alien.webp")
background=Actor("bg.jpg")
import pgzrun
background.center=(WIDTH/2,HEIGHT/2)
alien.pos=pygame.mouse.get_pos()
def draw():
    screen.clear()
    background.draw()
    # Draw a red circle at the mouse position
    alien.draw()
    if txt:
        screen.draw.text(current_message,(alien.x - 80, alien.y - 70),fontsize=40,color="red")
def on_mouse_move(rel, buttons):
    if mouse.LEFT in buttons:
        alien.pos=pygame.mouse.get_pos()
def update():
    if alien.y<550 and not keyboard.SPACE:
        alien.y+=5
    if alien.y>=400:
        if keyboard.RIGHT or keyboard.D:
            alien.x+=5
        if keyboard.LEFT or keyboard.A:
            alien.x-=5
        if alien.y>=550:
            if keyboard.SPACE:
                alien.y-=150
    if keyboard.X:
        screen.draw.filled_circle((alien.x,alien.y), 30, (255, 0, 0))
        
def on_mouse_down():
    global txt,current_message
    txt=True
    messages = ["HEY!","PUT ME DOWN!","GET OFF ME!","YOU ARE A BULLY!"]
    current_message = random.choice(messages)
    clock.schedule_unique(hide, 2.0)
def hide():
    global txt
    txt=False

def on_key_down(key):
    if key == keys.F:
        # Toggle fullscreen
        current_flags = screen.surface.get_flags()
        if current_flags & pygame.FULLSCREEN:
            pygame.display.set_mode((WIDTH, HEIGHT))  # back to windowed
        else:
            pygame.display.set_mode((0, 0), pygame.FULLSCREEN)  # go fullscreen
            background.center=(WIDTH/2,HEIGHT/2)
    elif key == keys.ESCAPE:
        # Exit the game
        pygame.display.set_mode((1200,600))
pgzrun.go()
import pygame,pgzrun,random

WIDTH = 1600
HEIGHT = 800
fullscreen = True
showtxt=True
showst=False
showattack=False
game=False
# Global dictionary to track pressed keys
keys_held = {"left": False,"right": False,"up": False,"down": False}

bar=Actor("hitbar.png")
heart=Actor("heart.png")
sans=Actor("sans.png")
current_message=""
heart.pos=(795,650)
bar.topleft=(100,600)
battle_box=Rect((570,500),(450,300))
sans.midbottom=(WIDTH/2,HEIGHT/2)
def draw():
    screen.fill((0,0,0))
    sans.draw()
    if showtxt:
        rect=Rect((200,600),(1200,300))
        screen.draw.rect(rect,(255,255,255))
        screen.draw.text("Its a beautiful day outside",topleft=(220,620),color="white",fontsize=50)
        screen.draw.text("Birds are singing, flowers are blooming",topleft=(220,670),color="white",fontsize=50)
        screen.draw.text("on days like this kids like you",topleft=(220,720),color="white",fontsize=50)
        screen.draw.text("should be burn in hell",topleft=(220,770),color="red",fontsize=50)
    if showst:
        rect=Rect((200,600),(1200,200))
        screen.draw.rect(rect,(255,255,255))
        screen.draw.text("*You filled with determination",topleft=(220,620),color="white",fontsize=50)
        screen.draw.text("Chara   Lv18           hp                                                        92/92",topleft=(200,810),color="white",fontsize=50)
        rect1=Rect((200,850),(275,50))
        rect2=Rect((500,850),(275,50))
        rect3=Rect((812,850),(275,50))
        rect4=Rect((1125,850),(275,50))
        screen.draw.rect(rect1,("yellow"))
        screen.draw.rect(rect2,("orange"))
        screen.draw.rect(rect3,("orange"))
        screen.draw.rect(rect4,("orange"))
        heart.topleft=(210,850)
        heart.draw()
        screen.draw.text("",topleft=(220,620),color="orange",fontsize=50)
        screen.draw.text("Fight",topleft=(270,860),color="yellow",fontsize=50)
        screen.draw.text("Act",topleft=(570,860),color="orange",fontsize=50)
        screen.draw.text("Item",topleft=(882,860),color="orange",fontsize=50)
        screen.draw.text("Mercy",topleft=(1195,860),color="orange",fontsize=50)
    if showattack:
        rect=Rect((200,600),(1200,200))
        screen.draw.rect(rect,(255,255,255))
        pygame.draw.ellipse(screen.surface,("yellow"),(220,610,1160,180))
        pygame.draw.ellipse(screen.surface,(0,0,0),(240,620,1120,160))
        screen.draw.filled_rect(Rect((300,655),(30,90)),("red"))
        screen.draw.filled_rect(Rect((1270,655),(30,90)),("red"))
        screen.draw.filled_rect(Rect((570,625),(30,157)),("yellow"))
        screen.draw.filled_rect(Rect((1000,625),(30,157)),("yellow"))
        screen.draw.filled_rect(Rect((750,620),(30,160)),("green"))
        screen.draw.filled_rect(Rect((820,620),(30,160)),("green"))
        screen.draw.text("Chara   Lv18           hp                                                        92/92",topleft=(200,810),color="white",fontsize=50)
        rect1=Rect((200,850),(275,50))
        rect2=Rect((500,850),(275,50))
        rect3=Rect((812,850),(275,50))
        rect4=Rect((1125,850),(275,50))
        screen.draw.rect(rect1,("yellow"))
        screen.draw.rect(rect2,("orange"))
        screen.draw.rect(rect3,("orange"))
        screen.draw.rect(rect4,("orange"))
        heart.topleft=(210,850)
        heart.draw()
        screen.draw.text("",topleft=(220,620),color="orange",fontsize=50)
        screen.draw.text("Fight",topleft=(270,860),color="yellow",fontsize=50)
        screen.draw.text("Act",topleft=(570,860),color="orange",fontsize=50)
        screen.draw.text("Item",topleft=(882,860),color="orange",fontsize=50)
        screen.draw.text("Mercy",topleft=(1195,860),color="orange",fontsize=50)
        
        bar.draw()
        if bar.right>1500:
            screen.draw.text("Miss",topleft=(1000,400),color="gray",fontsize=150)
            bar.x=1000000
    if game==True:
        screen.draw.rect(Rect((570,500),(450,300)),(255,255,255))
        heart.draw()

def on_key_down(key):
    global showtxt,showst,showattack,game
    if game==True:
        if key in [keys.LEFT, keys.A]:
            keys_held["left"] = True
        elif key in [keys.RIGHT, keys.D]:
            keys_held["right"] = True
        elif key in [keys.UP, keys.W]:
            keys_held["up"] = True
        elif key in [keys.DOWN, keys.S]:
            keys_held["down"] = True
        return
    if showtxt==True and key==keys.SPACE:
        showtxt=False
        showst=True
    if showst==True and key==keys.Z and showattack==False:
        showattack=True
        showst=False
    if showattack==True and key==keys.SPACE:
        game=True
        showattack=False
    if key == keys.F:
        # Toggle fullscreen
        current_flags = screen.surface.get_flags()
        if current_flags & pygame.FULLSCREEN:
            pygame.display.set_mode((WIDTH, HEIGHT))  # back to windowed
        else:
            pygame.display.set_mode((0, 0), pygame.FULLSCREEN)  # go fullscreen
            sans.midbottom=(WIDTH/2,HEIGHT/2)
    elif key == keys.ESCAPE:
        # Exit the game
        pygame.display.set_mode((1600,800))
def on_key_up(key):
    # Stop movement when key released
    if key in [keys.LEFT, keys.A]:
        keys_held["left"] = False
    elif key in [keys.RIGHT, keys.D]:
        keys_held["right"] = False
    elif key in [keys.UP, keys.W]:
        keys_held["up"] = False
    elif key in [keys.DOWN, keys.S]:
        keys_held["down"] = False

def update():  
    if showattack:
        bar.x+=5
    if game:
        bar.x=100
    if game:
        if keys_held["left"]:
            heart.x -= 5
        if keys_held["right"]:
            heart.x += 5
        if keys_held["up"]:
            heart.y -= 5
        if keys_held["down"]:
            heart.y += 5
            # Keep the heart inside the box
        if heart.left < battle_box.left:
            heart.left = battle_box.left
        if heart.right > battle_box.right:
            heart.right = battle_box.right
        if heart.top < battle_box.top:
            heart.top = battle_box.top
        if heart.bottom > battle_box.bottom:
            heart.bottom = battle_box.bottom
pgzrun.go()
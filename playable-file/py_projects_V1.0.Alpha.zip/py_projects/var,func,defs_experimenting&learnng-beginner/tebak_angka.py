import os

def delete():
    os.system('cls' if os.name == 'nt' else 'clear')

guess = []
myguess = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
mygsslis = [1, 2, 3, 4, 'nothing']

def yourgss():
    print("giliranmu menebak. pakai: apakah angka ke-n adalah x")
    yourguess = input(">")

    # Angka ke-1
    if yourguess == 'apakah angka ke-1 adalah 1': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 2': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 3': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 4': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 5': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 6': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 7': print("benar :)")
    elif yourguess == 'apakah angka ke-1 adalah 8': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 9': print("salah :)")
    elif yourguess == 'apakah angka ke-1 adalah 0': print("salah :)")

    # Angka ke-2
    elif yourguess == 'apakah angka ke-2 adalah 1': print("salah :)")
    elif yourguess == 'apakah angka ke-2 adalah 2': print("salah :)")
    elif yourguess == 'apakah angka ke-2 adalah 3': print("salah :)")
    elif yourguess == 'apakah angka ke-2 adalah 4': print("salah :)")
    elif yourguess == 'apakah angka ke-2 adalah 5': print("salah :)")
    elif yourguess == 'apakah angkamu adalah 1942': print("selamat")
    elif yourguess == 'apakah angka ke-2 adalah 6': print("salah :)")
    elif yourguess == 'apakah angka ke-2 adalah 7': print("salah :)")
    elif yourguess == 'apakah angka ke-2 adalah 8': print("salah :)")
    elif yourguess == 'apakah angka ke-2 adalah 9': print("benar :)")
    elif yourguess == 'apakah angka ke-2 adalah 0': print("salah :)")

    # Angka ke-3
    elif yourguess == 'apakah angka ke-3 adalah 1': print("salah :)")
    elif yourguess == 'apakah angka ke-3 adalah 2': print("salah :)")
    elif yourguess == 'apakah angka ke-3 adalah 3': print("salah :)")
    elif yourguess == 'apakah angka ke-3 adalah 4': print("benar :)")
    elif yourguess == 'apakah angka ke-3 adalah 5': print("salah :)")
    elif yourguess == 'apakah angka ke-3 adalah 6': print("salah :)")
    elif yourguess == 'apakah angka ke-3 adalah 7': print("benar :)")
    elif yourguess == 'apakah angka ke-3 adalah 8': print("salah :)")
    elif yourguess == 'apakah angka ke-3 adalah 9': print("salah :)")
    elif yourguess == 'apakah angka ke-3 adalah 0': print("salah :)")

    # Angka ke-4
    elif yourguess == 'apakah angka ke-4 adalah 1': print("salah :)")
    elif yourguess == 'apakah angka ke-4 adalah 2': print("benar :)")
    elif yourguess == 'apakah angka ke-4 adalah 3': print("salah :)")
    elif yourguess == 'apakah angka ke-4 adalah 4': print("salah :)")
    elif yourguess == 'apakah angka ke-4 adalah 5': print("salah :)")
    elif yourguess == 'apakah angka ke-4 adalah 6': print("salah :)")
    elif yourguess == 'apakah angka ke-4 adalah 7': print("benar :)")
    elif yourguess == 'apakah angka ke-4 adalah 8': print("salah :)")
    elif yourguess == 'apakah angka ke-4 adalah 9': print("salah :)")
    elif yourguess == 'apakah angka ke-4 adalah 0': print("salah :)")
    else:
        print("salah :)")

while True:
    print("kali ini kita akan bermain tebak angka, coba juga tebak angkaku")
    print("pikirkan angka 4")
    if mygsslis[0]=='nothing':
    	myanswer=guess[0],guess[1],guess[2],guess[3]
    	print(f"pasti angkamu itu {myanswer}")
    	break
    else:
    	print(f"apakah angka ke-{mygsslis[0]}mu adalah angka {myguess[0]}? y/n")
    imputs = input(">")
    print(myguess)
    print(mygsslis)

    if imputs == 'n':
        print("aihh")
        myguess.append(myguess[0])
        del myguess[0]
        print(myguess)

    if imputs == 'y':
        print("hahhaha bisa mi ku tebak jawabanmu ini :)")
        del mygsslis[0]
        print(mygsslis)
        guess.append(myguess[0])
        myguess.append(myguess[0])
        del myguess[0]
    


    yourgss()

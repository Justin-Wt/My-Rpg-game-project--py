#language options
language=input("pilih bahasa | choose your language (indonesia atau english)")

#for language=indonesia
if language=="indonesia":
	print("halo")
	print("hari ini, aku akan menentukan apakah kamu adalah Anak-anak, Remaja, Dewasa, atau Lansia berdasarkan umurmu")

#users input
	inputs=input("masukkan umurmu: ")
	age=int(inputs)
	if age<=12:
		print("kamu adalah Anak-anak")
	elif age>12 and age <=19:
		print("kamu adalah Remaja")
	elif age>19 and age <=59:
		print("kamu adalah Dewasa")
	elif age>=60:
		print("kamu adalah Lansia")
#first choice
	picks=input("apakah kamu ingin lanjut? y/n ")
	if picks=='n' or picks=='N':
		print("terima kasih telah memasukkan usia anda")
#while loops
	while picks=='y' or picks=='Y':
		inputs=input("masukkan umurmu: ")
		age=int(inputs)
		if age<=12:
			print("kamu adalah Anak-anak")
		elif age>12 and age <=19:
			print("kamu adalah Remaja")
		elif age>19 and age <=59:
			print("kamu adalah Dewasa")
		elif age>=60:
			print("kamu adalah Lansia")
#second choice
		picks = input("Do you want to continue? y/n: ")
		if picks == 'n' or picks=='N':
			print("terima kasih telah memasukkan usia anda")
			break

#for language=english
elif language =="english":
	print("hello")
	print("today, i'll determine whether you are a Child, Teenager, Adult, or Senior based on your age")

#users input
	inputs=input("input your age: ")
	age=int(inputs)
	if age<=12:
		print("you are a Child")
	elif age>12 and age <=19:
		print("you are a Teenager")
	elif age>19 and age <=59:
		print("you are an Adult")
	elif age>=60:
		print("you are a Senior")
#first choice
	picks=input("do you still wants to continue? y/n ")
	if picks=='n' or picks=='N':
		print("Thanks for inputting your age")
#while loops
	while picks=='y' or picks=='Y':
		inputs=input("input your age: ")
		age=int(inputs)
		if age<=12:
			print("you are a Child")
		elif age>12 and age <=19:
			print("you are a Teenager")
		elif age>19 and age <=59:
			print("you are an Adult")
		elif age>=60:
			print("you are a Senior")
#second choice
		picks = input("Do you want to continue? y/n: ")
		if picks == 'n' or picks=='N':
			print("Thanks for inputting your age")
			break

#other language
else:
	print("thats not an option")
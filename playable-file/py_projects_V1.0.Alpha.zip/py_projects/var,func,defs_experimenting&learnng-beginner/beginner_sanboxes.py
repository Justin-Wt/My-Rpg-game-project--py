name,age,birthday="justin",16,2009
print(name)
print(age)
print(birthday)
input("for the multiple var")
my_1st_number,my_2nd_number,my_3rd_number=5,4,5
if my_1st_number>my_2nd_number and my_2nd_number>my_3rd_number:
	print(f"the number is sorter from biggest to smallest")
if my_1st_number==my_3rd_number and my_1st_number>my_2nd_number or my_1st_number==my_2nd_number and my_1st_number>my_3rd_number or my_2nd_number==my_3rd_number and my_2nd_number>my_1st_number:
	print("theres a same nunber and its bigger than the small number")
else:
	print("its kinda unique")
input("for boolean")
x=10
if 0<x<20:
	print("x is bigger than 0 and smaller than 20")
input("for chaining comparison")

number=input("enter any number please: >")
try:
	number=int(number)
except ValueError:
	print("please enter a number")
else:
	print(f"you picked number {number}")
finally:
	print("thank you")

input("for interactive inputting")


while True:
	num1=input("enter your first number: ")
	num2=input("enter your second number: ")
	num3=input("enter your third number: ")
	try:
		num1,num2,num3=int(num1),int(num2),int(num3)
	except ValueError:
		print("thats not a number")
		continue
	else:
		if num1>num2 and num1>num3:
			print("your biggest number is your first number")
		elif num2>num1 and num2>num3:
			print("your biggest number is your second number")
		elif num3>num1 and num3>num2:
			print("your biggest number is your third number")
		if num1 == num2 or num1 == num3 or num2==num3:
			print("you have 2 same number")
		if num1==num2==num3:
			print("you have all the same number")
		if num1<num2<num3:
			print("you sorted the number from small to biggest")
	input("click enter to continue")
	break
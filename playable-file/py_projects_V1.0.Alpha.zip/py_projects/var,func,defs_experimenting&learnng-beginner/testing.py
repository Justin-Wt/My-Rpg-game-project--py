import random
import os
import sys
import time
WINDOWS=os.name=='nt'
if WINDOWS:
    import msvcrt
else:
    import termios, tty, select
def delete():
    os.system('cls' if os.name == 'nt' else 'clear')
def clear_keystrokes():
    if WINDOWS:
        while msvcrt.kbhit():
            msvcrt.getch()
    else:
        while select.select([sys.stdin], [], [], 0)[0]:
            sys.stdin.read(1)
def typing(text):
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()
    if not WINDOWS:
        old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())

    try:
        for c in text:
            clear_keystrokes()
            sys.stdout.write(c)
            sys.stdout.flush()
    finally:
        if not WINDOWS:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()
def a():
	f=random.randrange(90,100)
	fs=(f"\033[{f}m")
	return fs
def s():
	z=str(random.randrange(1,10))
	return z
def char():
	chaar = chr(random.randint(33, 126))
	return chaar
def chars():
	charss = chr(random.randint(0x0400, 0x04FF))
	return charss
def x():
	ss=(f"{a()}{s()}{a()}{char()}{a()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}{a()}{s()}{a()}{char()}{chars()}")
	return ss
while True:
	typing(x())

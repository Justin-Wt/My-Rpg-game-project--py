class Inventory:
	def __init__(self,weapon="Empty",health_potion=0,mana_potion=0,armor="Empty"):
		potion=f"health potion={health_potion}\n           -mana potion={mana_potion}"
		inventory=({"weapon":weapon,"potion":potion,"armor":armor})
		self.inventory=inventory
	def count(self):
		return len(self.inventory.items)
	def __str__(self):
		my_inventory=[]
		for name,item in self.inventory.items():
			my_inventory.append(f"        {name}:\n           -{item}")
		my_inventory="\n".join(my_inventory)
		return f"{my_inventory}"
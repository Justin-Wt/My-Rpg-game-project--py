import random
print(random.__file__)
input()
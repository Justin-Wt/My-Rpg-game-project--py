RED="\033[31m"
BLUE="\033[34m"
BRIGHT_YELLOW="\033[1;33m"
YELLOW="\033[33m"
GREEN="\033[32m"
END="\033[0m"
enemies=[
	("Goblin",30,5,2),
	("Wolf",40,7,3),
	("Bat",25,4,1)
]
def show_index():
	print(f"{'enemy-index':-^32}")
	for index,enemy in enumerate(enemies,1):
		name,hp,strength,defense=enemy
		rate=(hp+strength+defense)/10
		if rate<=3:
			rate=f'{GREEN}{rate}'
		elif rate<5:
			rate=f'{YELLOW}{rate}'
		else:
			rate=f'{RED}{rate}'
		print(f"{index}. {name:<16}rating: {rate}\n   {RED}HP: {hp:<3}\n   {BRIGHT_YELLOW}STR: {strength:<2}\n   {BLUE}DEF: {defense:<2}{END}\n{'':-<32}")
print("what you want to do?")
print("1.index")
print("2.explore")
print("3.Rest")
choice=input(">")
try:
	choice=int(choice)
except ValueError:
	print("thats not a choice")
else:
	if choice==1:
		show_index()
input()
import random
RED = "\033[0;31m"
BLUE = "\033[0;34m"
YELLOW = "\033[1;33m"
END = "\033[0m"
class Enemy:
    def __init__(self,name="None",level=1,base_hp=10,base_strength=3,base_defense=2,loot=None,drop_multi=1):
       self.name=name
       self.level=level
       self.hp=base_hp+3*level
       self.strength=base_strength+level
       self.defense=base_defense+level
       self.drop_multi=drop_multi
       self.loot=loot if loot is not None else []
       
    def take_damage(self,player):
        dmg_taken=max(0,player.strength-self.defense)
        print(f"the {self.name} taken {dmg_taken} damage")
        
    def attack(self,player):
        damage=max(0,self.strength-player.defense)
        player.hp=max(0,player.hp-damage)
        print(f"the {self.name} dealt {damage} damage")
        return damage
        
    def drop_loot(self):
        dropped_item=[]
        for item,minimum,maximum in self.loot:
            amount=random.uniform(minimum,maximum)
            amount=int(amount*self.drop_multi)
            if amount>0:
                dropped_item.append((item,amount))
        if not dropped_item:
            print(f"The {self.name} dropped nothing")
        else:
            print(f"the {self.name} has dropped:\n-",end='')
            print("\n-".join(f"{amount} {item}" for item,amount in dropped_item))
        return dropped_item
        
    @classmethod
    def from_area(cls, area, tier):
        ranks = {
            "normal": (1, 1, 1),
            "elite": (1.5, 1.3, 2),
            "boss": (3, 2, 5)
        }
        if tier not in ranks:
            return None
        hp_multi,strength_multi,drop_multi=ranks.get(tier)
        level=random.randint(1,20)
        areas={
            "forest": [
                ("Goblin",level, 10, 2, 1, [("gold", 75, 150),("goblin necklace",0,1)]),
		 	   ("Wolf",level, 12, 3, 4, [("gold", 80, 180),("fang",0,3)])
                ],
            "cave": [
                ("Slime",level, 8, 1, 0, [("gold", 5, 20),("slime gel", 1, 4),("health potion", 0, 1),("sticky core", 0, 0.1)]),
                ("Bat", level, 9, 2, 1, [("gold",5,10),("bat wing", 0, 1),("echo dust", 0, 1),("blood vial", 0, 0.5),("bat fang", 0, 0.1)])
                ]
            }
        test_area = areas.get(area)
        if test_area is None:
            print("that's not a valid zone")
            return None
        name, lvl, hp, strength, defense, loot = random.choice(test_area)

        return cls(
            name,
            lvl,
            int(hp * hp_multi),
            int(strength* strength_multi),
            defense,
            loot,
            drop_multi
        )
    def __str__(self):
        return f"{self.name:<10} level:{self.level}\n{'':-<20}\n{RED}hp:{self.hp}{END}\n{YELLOW}strength:{self.strength}{END}\n{BLUE}defense:{self.defense}{END}\n{'':-<20}"
if __name__=="__main__":
    enemy=Enemy.from_area("cave","boss")
    print(enemy)
    enemy.drop_loot()
    input()
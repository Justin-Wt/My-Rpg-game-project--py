pl=[]
pl.append(1,2,4,2,1,41,24)
print(pl)
print(pl)
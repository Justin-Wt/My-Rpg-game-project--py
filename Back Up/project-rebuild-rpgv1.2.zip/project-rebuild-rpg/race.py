# race.py
def get_races():
    """Return a list of races and their stats."""
    races = [
        ("Elf", 21, 12, 3, 1),
        ("Orc", 26, 7, 9, 1),
        ("Demon", 20, 18, 2, 1),
        ("Human", 19, 17, 6, 1)
    ]
    return races

def show_race():
    """Print available races and their stats nicely."""
    races = get_races()
    for i, (name, hp, strength, defense, _) in enumerate(races, start=1):
        print(f"{i}. {name}\n{'':-<20}\nHP: {hp}\nStrength: {strength}\nDefense: {defense}\n{'':-<20}\n")

def race_pick(choice):
    """Return the stats of the selected race as a tuple."""
    races = get_races()
    return races[choice]
		
if __name__=="__main__":
	show_race()
	race_pick(1)
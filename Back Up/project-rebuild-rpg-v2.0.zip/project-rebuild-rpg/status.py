class StatusEffect:
    def __init__(self, name, damage=0, duration=3):
        self.name = name
        self.damage = damage
        self.duration = duration

    def on_apply(self, target):
        print(f"{target.name} is affected by {self.name}!")

    def on_tick(self, target):
        if self.damage > 0:
            target.hp = max(0, target.hp - self.damage)
            print(f"{target.name} takes {self.damage} damage from {self.name}.")

        self.duration -= 1

    def is_expired(self):
        return self.duration <= 0

    def on_end(self, target):
        print(f"{self.name} on {target.name} has ended.")
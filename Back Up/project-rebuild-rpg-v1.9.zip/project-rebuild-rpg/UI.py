# Imports
import pygame
import sys
from player import  Player
from race import  race_pick

race,hp,defense,strength=race_pick(2)
player=Player("justin",race,hp,strength,defense)

# Boot Up
pygame.init()
pygame.key.start_text_input()

# Get screen info
info = pygame.display.Info()
width, height = info.current_w, info.current_h
screen = pygame.display.set_mode((width, height))
ui_surface = pygame.Surface((width, height))
base_w, base_h = 800, 1200

# Offsets Menu

UI_W,UI_H=int(-0.15*width),0

# Landscape and portrait stabilizer
def update_button_positions():
    new_game_button.rect.topleft = (width // 2 - btn_w // 2 ,rect_h + int(300 * scale))
    load_button.rect.topleft = (width //2 - btn_w // 2 ,rect_h + int(400 * scale))
    start_button.rect.topleft = (width // 2 - btn_w // 2 , rect_h + int(300 * scale))
    quit_button.rect.topleft = (width // 2 - btn_w // 2, rect_h + int(400 * scale))
    attack_button.rect.topleft = (width // 2 - btn_w // 4+UI_W*2, rect_h + int(300 * scale))
    magic_button.rect.topleft  = (width // 2 - btn_w // 4+UI_W*2, rect_h + int(400 * scale))

def handle_gameplay_input(event):
    pass

# Button class
class Button:
    def __init__(self, x, y, w, h, text, color="gray", hover_color=(100,100,100)):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.clicked = False

    def draw(self, surface, is_selected=False):
        color = self.hover_color if is_selected else self.color
        # Mouse position for PC version later
        mouse_pos = pygame.mouse.get_pos()
        ui_mouse = (mouse_pos[0] - UI_W, mouse_pos[1] - UI_H)
        pygame.draw.rect(surface, color, self.rect)
        text_surf = font.render(self.text, True, (0, 0, 0))
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                return True
        return False

# Scaling
scale = max(0.75, min(min(width / base_w, height / base_h), 1.2))
btn_w = int(380 * scale)
btn_h = int(60 * scale)
bar_h = int(30 * scale) + UI_H
text_w = width // 2 - int(440 * scale) + UI_W*1.8
rect_w = width // 2 - int(200 * scale // 2)+UI_W*2
rect_h = height // 2 + UI_H
font = pygame.font.Font(None, int(100 * scale))

# Buttons
new_game_button = Button(rect_w, rect_h + int(300 * scale), btn_w, btn_h, "New Game", "white")
load_button = Button(rect_w, rect_h + int(400 * scale), btn_w, btn_h, "Load", "white")
start_button = Button(rect_w, rect_h + int(300 * scale), btn_w, btn_h, "Start", "white")
quit_button = Button(rect_w, rect_h + int(400 * scale), btn_w, btn_h, "Quit", "white")
attack_button = Button(rect_w, rect_h + int(300 * scale), btn_w, btn_h, "Attack", "white", "yellow")
magic_button = Button(rect_w, rect_h + int(400 * scale), btn_w, btn_h, "Magic", "white", "yellow")
name_surf= font.render(f"{player.name:<16} lvl.{player.level}",True,(255,255,255))
atb_surf = font.render("  ATB:", True, (0,150,255))
hp_surf = font.render("   HP:", True, (255,0,0))
magic_surf = font.render("Magic:", True, (128,0,128))

update_button_positions()
# Time and cooldown
atb = 0
fps_timer = 0
speed = 120
cast_time = 0
clock = pygame.time.Clock()
pygame.display.set_caption("My First Pygame")

# Text input
text = ""
text_surface = font.render(text, True, (255,255,255))

state = "Start"  # Start menu
total_hp=player.hp #Total Hp
# Main loop
fps_surf = font.render("0", True, (255,255,255))
action_selected = None
running = True
while running:
    # Time and FPS handler
    dt = clock.tick(60) / 1000
    fps_timer += dt
    if state=="Fight":
        player.update_atb(dt)
        player.update_action(dt)
    # Event handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Start menu button handling
        if state == "Start":
            if start_button.handle_event(event):
                state = "Fight"
            elif quit_button.handle_event(event):
                running = False

        # Gameplay input
        if state == "GamePlay":
            handle_gameplay_input(event)

        # Text input
        if event.type == pygame.TEXTINPUT:
            text += event.text
            text_surface = font.render(text, True, (255,255,255))
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                text = text[:-1]
                text_surface = font.render(text, True, (255,255,255))

        # Window resize
        if event.type == pygame.VIDEORESIZE:
            info = pygame.display.Info()
            width, height = info.current_w, info.current_h
            ui_surface = pygame.Surface((width, height))
            scale = max(0.75, min(min(width / base_w, height / base_h), 1.2))
            btn_w = int(380 * scale)
            btn_h = int(60 * scale)
            bar_h = int(30 * scale) + UI_H
            text_w = width // 2 - int(440 * scale)+UI_W*2+30
            rect_w = width // 2 - int(200 * scale //2)+UI_W*2
            rect_h = height//2 + UI_H
             
            font = pygame.font.Font(None, int(100 * scale))
            update_button_positions()

        # ATB button handling
        if player.atb >= 100:
            if attack_button.handle_event(event):
                player.select_action("Attack")
                player.update_action(dt)
                print("attack")
                
            elif magic_button.handle_event(event):
                action_selected="Magic"
                player.select_action("Magic")
                player.update_action(dt)
                

    # Logic handler
    hp_ratio=player.hp/total_hp
    atb_ratio=player.atb/100
    # Drawing
    ui_surface.fill((0, 0, 0))
    if state == "Start":
        start_button.draw(ui_surface)
        quit_button.draw(ui_surface)
    elif state == "Saves":
        new_game_button.draw(ui_surface)
        load_button.draw(ui_surface)
    elif state == "Fight":
        pygame.draw.rect(ui_surface, (100,100,100), (0, rect_h, width, height))
        ui_surface.blit(text_surface, (width//2, height//2))
        if fps_timer >= 0.2:
            fps_surf = font.render(f"FPS:{int(1/dt)}", True, (255,255,255))
            fps_timer = 0
        pygame.draw.rect(ui_surface, (50,50,50), (rect_w, rect_h + int(125*scale), rect_w*2, bar_h))
        pygame.draw.rect(ui_surface, (255,0,0), (rect_w, rect_h + int(225*scale),hp_ratio*rect_w*2, bar_h))
        pygame.draw.rect(ui_surface, (0,150,255), (rect_w, rect_h + int(125*scale), atb_ratio*rect_w*2, bar_h))
        ui_surface.blit(name_surf,(text_w,rect_h*scale))
        ui_surface.blit(fps_surf, (0,0))
        ui_surface.blit(hp_surf, (text_w, rect_h + int(200*scale)))
        ui_surface.blit(atb_surf, (text_w, rect_h + int(100*scale)))
        if player.action_selected=="Magic":
            ui_surface.blit(magic_surf,(text_w,rect_h))
            pygame.draw.rect(ui_surface,("purple"),(rect_w,rect_h+int(25*scale),player.cast_time*btn_w/100,bar_h))

        if player.atb >= 100:
            attack_button.draw(ui_surface)
            magic_button.draw(ui_surface)

    screen.fill((0,0,0))
    screen.blit(ui_surface, (0,0))
    pygame.display.flip()

pygame.quit()
sys.exit()
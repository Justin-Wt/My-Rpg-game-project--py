from player import Player
from scores import save_player,view,TopScore,reset
from race import race_pick, show_race
from inventory import Inventory
from shop import shop_menu

name=input("whats your name?")
show_race()
pick=int(input("what race you want to pick? "))-1
race,hp,strength,defense,level=race_pick(pick)

player=Player(name,race,hp,strength,defense,level)
print(player)
shop_menu(player)
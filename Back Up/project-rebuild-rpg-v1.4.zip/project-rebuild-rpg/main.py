from player import Player
from scores import save_player,view,TopScore,reset
from race import race_pick, show_race
from inventory import Inventory
from shop import shop_menu
'''
time developed: 52 hours + 179 hours from first prototype.
19 hours+ spent on learning
--------------------------updates--------------------------
V1.0:creating main.py,scores.py,player.py
V1.1:creating inventory.py,enemy.py
V1.2:updating inventory.py,enemy.py and creating battle.py
V1.3:creating shop.py,race.py and creating ranks
V1.4:updating race.py,enemy.py
----------------------UpcomingFeature----------------------
0.using json and making def equip armor,weapon,accessory
1.Skills
2.more enemy choices
3.crafting
4.better UI
5.converting to LUA
6.converting into pygame
7.converting into .exe
8.converting into .apk
9.using cv2
10.using socket
---------RecapStuffILearnedInFirstVersionOfRpg.py---------
1.print
2.variables
3.strings
4.methods
5.input
6.condition (if,elif,else,and,or,not)
7.comparison(<,>,<=,>=,==,!=)
8.f-string
9.list
10.for loop and while loop
11.Def
12.return
13.tuple
14.dictionary
15.while True
16.global
17.error handler (try,except,else,finally)
18.multiple def connected
19.random (randrange,randint)
20.increase & decrease value (-=,+=,*=)
21.def with parameter (def main(parameter))
22.using while with variables (while item>amount:)
23.using ansi color
24.using os.system('cls' if os.name == 'nt' else 'clear')
25.using typing(text,time)
26.using limiter to increase a value (if xp<rec: lvl+=1)
---------------------NewThingsILearned---------------------
1.replace all  name at once (ctrl+H)
2.classes
3.__init__
4.__str__
5.@classmethod
6.@staticmethod
7.@property
8.instance method
9.if __name__=="__main__":
10.if __name__=="File.py":
11.format specifier
12.lambda
13.*args and **kwargs
14.get().
15.types in types {[("str",int),("str",int)],[("str",int),("str",int)]}
16.one line specify and exec it -if choice in (item for name,item in list)
17."".join()
18.except FileNotFounderror
19.random (uniform,randchoice)
20.using x[1][0] to declare something in dict,tuples or list
-----------------------------------------------------------
'''
name=input("whats your name?")
show_race()
pick=int(input("what race you want to pick? "))-1
race,hp,strength,defense,level=race_pick(pick)

player=Player(name,race,hp,strength,defense,level)
print(player)
shop_menu(player)